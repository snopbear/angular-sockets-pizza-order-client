export interface IPizzaOrders {
  pizzaId: number;
  pizzaName: string;
  orderDate: Date;
}
