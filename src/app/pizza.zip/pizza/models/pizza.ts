export interface IPizza {
  pizzaId: number;
  pizzaName: string;
  ingredients: string;
  price: number;
  imageUrl: string;
}
