export interface IPizzaCount {
  _id: string;
  count: number;
}
